// src/App.js
import React from "react";
import {ShoppingCart} from './components/shoppingCart';
import {PRODUCTS} from './productData/products'

const App = () => {
  return (
    <div className="App">
      <ShoppingCart productData = {PRODUCTS} />
    </div>
  );
};

export default App;
