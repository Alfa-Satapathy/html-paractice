import React from "react";

export const ShoppingCartHeader = ({productList}) => {
 //Implement the  productItemCount logic.It is hardcored to 2 for now.
 //productitemCount should be total quantity of all product items in the cart.


  const productItemCount = 2

  return (
    <header className="container">
      <h2>Your Cart</h2>
      <p><span>{productItemCount}</span> items in the cart</p>
    </header>
  );
};
