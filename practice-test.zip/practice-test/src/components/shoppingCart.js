import React, { useState } from "react";
import { ShoppingCartHeader } from "./shoppingCartHeader";
import  { ProductList } from "./productlist";
import  {PriceSummary} from "./pricesummary";

export const ShoppingCart = ({productData}) => {
  const [productList, setProductList] = useState(productData);

  return (
    <div>
      <ShoppingCartHeader productList={productList} />
      {productList.length > 0 ? (
        <div>
          <ProductList 
            productList={productList}
            setProductList={setProductList}
          />
          <PriceSummary
            productList={productList} />
        </div>
      ) : (
        <div className="empty-product">
          <h3>Cart is Empty</h3>
         
        </div>
      )}
    </div>
  );
};
