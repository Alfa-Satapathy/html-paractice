import React from "react";
import { currencyFormat } from "../utility/currencyexchange";

export const PriceSummary = ({ productList }) => {
  const tax = 20; // tax is fixed value. No need to update this value.

    // Complete the subtotal and total calculations. Write now it is hardcoded.
    //Subtotal is the sum of all product prices multiplied by their quantities.
    //Subtotal will be changed based on the products in the cart.
    

  const subTotal = 100
  const total = subTotal + tax;

  return (
    <section className="container">
      <div className="summary">
        <ul>
          <li>
            Subtotal <span>{currencyFormat(subTotal)}</span>
          </li>
          <li>
            Tax <span>{currencyFormat(tax)}</span>
          </li>
          <li className="total">
            Total <span>{currencyFormat(total)}</span>
          </li>
        </ul>
      </div>

      <div className="checkout">
        <button type="button">Check Out</button>
      </div>
    </section>
  );
};
