export const PRODUCTS = [
  {
    image: "https://fakestoreapi.com/img/81fPKd-2AYL._AC_SL1500_.jpg",
    name: "Product 1",
    description: "Description for Product 1",
    price: 6.03,
    quantity: 6,
  },
  {
    image: "https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_.jpg",
    name: "Product 2",
    description: "Description for Product 2",
    price: 7.89,
    quantity: 4,

  },

   {
    image: "https://fakestoreapi.com/img/71YXzeOuslL._AC_UY879_.jpg",
    name: "Product 3",
    description: "Description for Product 3",
    price: 4.45,
    quantity: 5,
  },
];

